package br.com.relogiosemprevisivel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ClockService extends Service {

    private static final String CHANNEL_ID = "clock_channel";
    private static final int NOTIFICATION_ID = 10;

    private WindowManager windowManager;
    private TextView clockView;
    private final Handler handler = new Handler();
    private final SimpleDateFormat timeFormat =
            new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    private final Runnable updateClock = new Runnable() {
        @Override
        public void run() {
            if (clockView != null) {
                clockView.setText(timeFormat.format(new Date()));
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification());

        if (Settings.canDrawOverlays(this)) {
            showClock();
        }
    }

    private void showClock() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        clockView = new TextView(this);
        clockView.setText(timeFormat.format(new Date()));
        clockView.setTextColor(Color.WHITE);
        clockView.setTextSize(22);
        clockView.setGravity(Gravity.CENTER);
        clockView.setPadding(14, 7, 14, 7);
        clockView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        clockView.setBackgroundResource(R.drawable.clock_background);

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 12;
        params.y = 55;

        clockView.setOnTouchListener(new View.OnTouchListener() {
            float downRawX;
            float downRawY;
            int startX;
            int startY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        startX = params.x;
                        startY = params.y;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        params.x = startX - Math.round(event.getRawX() - downRawX);
                        params.y = startY + Math.round(event.getRawY() - downRawY);
                        windowManager.updateViewLayout(clockView, params);
                        return true;

                    case MotionEvent.ACTION_UP:
                        return true;
                }
                return false;
            }
        });

        windowManager.addView(clockView, params);
        handler.post(updateClock);
    }

    private Notification buildNotification() {
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Relógio sempre visível")
                .setContentText("O relógio flutuante está ativo.")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Relógio sempre visível",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Notificação do relógio flutuante.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (clockView == null && Settings.canDrawOverlays(this)) {
            showClock();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(updateClock);

        if (clockView != null && windowManager != null) {
            try {
                windowManager.removeView(clockView);
            } catch (Exception ignored) {
            }
            clockView = null;
        }

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
