package br.com.relogiosemprevisivel;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int NOTIFICATION_REQUEST = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button permissionButton = findViewById(R.id.permissionButton);
        Button startButton = findViewById(R.id.startButton);
        Button stopButton = findViewById(R.id.stopButton);
        TextView status = findViewById(R.id.statusText);

        permissionButton.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
            } else {
                Toast.makeText(this, "Permissão já está liberada.", Toast.LENGTH_SHORT).show();
            }
        });

        startButton.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Primeiro permita 'Exibir sobre outros apps'.", Toast.LENGTH_LONG).show();
                return;
            }

            requestNotificationPermissionIfNeeded();
            Intent serviceIntent = new Intent(this, ClockService.class);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(this, serviceIntent);
            } else {
                startService(serviceIntent);
            }

            status.setText("Relógio ativo. Ele ficará sobre outros aplicativos.");
        });

        stopButton.setOnClickListener(v -> {
            stopService(new Intent(this, ClockService.class));
            status.setText("Relógio desligado.");
        });
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    NOTIFICATION_REQUEST
            );
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        TextView status = findViewById(R.id.statusText);
        if (Settings.canDrawOverlays(this)) {
            status.setText("Permissão de sobreposição liberada.");
        } else {
            status.setText("Permita 'Exibir sobre outros apps' para começar.");
        }
    }
}
